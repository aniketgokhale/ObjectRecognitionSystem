package com.example.himanshupalve.objrec2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DisplayActivity extends AppCompatActivity {


    ImageView outputImage;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        outputImage = findViewById(R.id.output);
        tv = findViewById(R.id.tv2);
        Glide.with(DisplayActivity.this)
                .load("http://192.168.43.96:5000/get")
                .into(outputImage);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Glide.with(DisplayActivity.this)
                        .load("http://192.168.43.96:5000/get")
                        .into(outputImage);
            }
        });
    }
}
